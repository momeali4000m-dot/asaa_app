Esaa (اسعى) Android project - mobile build edition.
Open the EsaaApp folder in AndroidIDE, then build/run.
The included gradlew bootstrap downloads Gradle 8.9 on first build.
Internet is required for the first build and Android dependencies.
