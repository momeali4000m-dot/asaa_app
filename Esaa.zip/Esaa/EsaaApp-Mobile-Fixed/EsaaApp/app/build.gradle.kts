plugins { id("com.android.application") }

android {
    namespace = "com.esaa.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.esaa.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
