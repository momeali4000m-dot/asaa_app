package com.esaa.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.esaa.app.R.layout.activity_main);
        status = findViewById(R.id.statusText);
        bind(R.id.btnFindJob, "قسم الباحثين عن عمل");
        bind(R.id.btnFindWorker, "قسم أصحاب العمل والباحثين عن عمال");
        bind(R.id.btnConstruction, "الإنشاءات");
        bind(R.id.btnEngineering, "الهندسة");
        bind(R.id.btnElectronics, "الإلكترونيات");
        bind(R.id.btnIndustry, "الصناعة");
    }

    private void bind(int id, String text) {
        Button b = findViewById(id);
        b.setOnClickListener(v -> status.setText("تم اختيار: " + text));
    }
}
